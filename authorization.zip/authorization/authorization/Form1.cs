﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace authorization
{
    public partial class Form1 : Form
    {

        private SqlConnection sqlConnection = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            const string connectionString = @"Data Source=DUCK\SQLEXPRESS;Initial Catalog=ПР5;Integrated Security=True;Encrypt=False";
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            if (sqlConnection.State == ConnectionState.Open) {
                MessageBox.Show("Успешное подключение к бд");
                string query = "SELECT СекретныйВопрос FROM СекретныйВопрос"; // Замените на ваш запрос
                SqlCommand command = new SqlCommand(query, sqlConnection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox1.Items.Add(reader["СекретныйВопрос"].ToString()); // Замените "ColumnName" на имя вашего столбца
                }

            }
            else {
                MessageBox.Show("Сервер не найден");
                this.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text) ||
                string.IsNullOrWhiteSpace(textBox5.Text) ||
                string.IsNullOrWhiteSpace(textBox6.Text) ||
                comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Все поля должны быть заполнены!");
                return;
            }

            // Проверка совпадения паролей
            if (textBox4.Text != textBox5.Text)
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            try
            {
                // Получаем КодСекретногоВопроса из таблицы СекретныйВопрос
                string secretQuestionQuery = "SELECT КодСекретногоВопроса FROM СекретныйВопрос WHERE СекретныйВопрос = @СекретныйВопрос";
                SqlCommand secretQuestionCommand = new SqlCommand(secretQuestionQuery, sqlConnection);
                secretQuestionCommand.Parameters.AddWithValue("@СекретныйВопрос", comboBox1.SelectedItem.ToString());
                int secretQuestionId = (int)secretQuestionCommand.ExecuteScalar();

                // Добавляем новую запись в таблицу Пользователь
                string insertQuery = @"
            INSERT INTO Пользователь (Фамилия, Имя, ЭлектроннаяПодпись, Пароль, КодоваеСлово, КодСекретногоВопроса)
            VALUES (@Фамилия, @Имя, @ЭлектроннаяПодпись, @Пароль, @КодоваеСлово, @КодСекретногоВопроса)";

                SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection);
                insertCommand.Parameters.AddWithValue("@Фамилия", textBox1.Text);
                insertCommand.Parameters.AddWithValue("@Имя", textBox2.Text);
                insertCommand.Parameters.AddWithValue("@ЭлектроннаяПодпись", textBox3.Text);
                insertCommand.Parameters.AddWithValue("@Пароль", textBox4.Text); // Добавляем пароль
                insertCommand.Parameters.AddWithValue("@КодоваеСлово", textBox6.Text);
                insertCommand.Parameters.AddWithValue("@КодСекретногоВопроса", secretQuestionId);

                insertCommand.ExecuteNonQuery();

                MessageBox.Show("Пользователь успешно добавлен!");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Ошибка при добавлении пользователя: " + ex.Message);
            }

        }
    }
}
